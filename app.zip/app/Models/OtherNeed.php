<?php 

// app/Models/OtherNeed.php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OtherNeed extends Model
{
    protected $fillable = ['name', 'stock'];
}
?>