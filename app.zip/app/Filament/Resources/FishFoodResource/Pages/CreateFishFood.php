<?php

namespace App\Filament\Resources\FishFoodResource\Pages;

use App\Filament\Resources\FishFoodResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFishFood extends CreateRecord
{
    protected static string $resource = FishFoodResource::class;
}
