<x-app-layout>
    @section('title', 'Transaksi')
    @section('main-content')
        @livewire('transaksi-component')
    @endsection
</x-app-layout>
