<x-app-layout>
    @section('title', 'Kebutuhan')
    @section('main-content')
        @livewire('fish-calculator')
    @endsection
</x-app-layout>
