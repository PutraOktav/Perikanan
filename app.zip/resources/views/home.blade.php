<x-app-layout>
    @section('title', 'HOME')
    @section('main-content')
        @livewire('dashboard')
    @endsection
</x-app-layout>
