<x-app-layout>
    @section('title', 'Kebutuhan Lain')
    @section('main-content')
        @livewire('manage-other-needs')
    @endsection
</x-app-layout>
