<x-app-layout>
    @section('title', 'HPP')
    @section('main-content')
        @livewire('hpp-component')
    @endsection
</x-app-layout>
