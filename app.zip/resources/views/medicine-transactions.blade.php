<x-app-layout>
    @section('title', 'Obat-Obatan')
    @section('main-content')
        @livewire('manage-medicines')
    @endsection
</x-app-layout>
