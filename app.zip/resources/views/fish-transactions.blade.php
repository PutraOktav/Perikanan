<x-app-layout>
    @section('title', 'Transaksi Ikan')
    @section('main-content')
        @livewire('manage-fish')
    @endsection
</x-app-layout>
