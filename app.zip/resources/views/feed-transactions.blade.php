<x-app-layout>
    @section('title', 'Transaksi Pakan')
    @section('main-content')
        @livewire('manage-feeds')
    @endsection
</x-app-layout>
