<x-app-layout>
    @section('title', 'Sampling')
    @section('main-content')
        @livewire('fish-farm-sampling-calculator')
    @endsection
</x-app-layout>
