<div>
    <h1 class="text-2xl font-semibold mb-4">List Stok Alat</h1>

    <!-- Form to add new Other Need -->
    <form wire:submit.prevent="store" class="mb-4">
        <div class="flex items-center mb-4">
            <label for="name" class="mr-2">Nama:</label>
            <input type="text" id="name" wire:model="name" placeholder="Masukkan Nama"
                class="border rounded-md px-3 py-1 w-60">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-500"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="flex items-center mb-4">
            <label for="stock" class="mr-2">Stok:</label>
            <input type="number" id="stock" wire:model="stock" placeholder="Masukkan Stok"
                class="border rounded-md px-3 py-1 w-32">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-500"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md">Tambah
            Lain</button>
    </form>

    <!-- List of Other Needs -->
    <table class="w-full border-collapse">
        <thead>
            <tr>
                <th class="px-4 py-2 border">Nama</th>
                <th class="px-4 py-2 border">Stok</th>
                <th class="px-4 py-2 border">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $otherNeeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $need): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-4 py-2 border"><?php echo e($need->name); ?></td>
                    <td class="px-4 py-2 border"><?php echo e($need->stock); ?> Unit</td>
                    <td class="px-4 py-2 border">
                        <button wire:click="delete(<?php echo e($need->id); ?>)"
                            class="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded-md">Hapus</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>
</div>
<?php /**PATH /home/pzgbtwqf/aquaticplanning.nokt.tech/resources/views/livewire/manage-other-needs.blade.php ENDPATH**/ ?>