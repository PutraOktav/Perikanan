<div class="bg-white shadow-md rounded-lg p-6">
    <div class="mb-4">
        <label for="jenis_produk" class="block font-bold mb-2">Jenis Produk:</label>
        <input type="text" id="jenis_produk" wire:model="jenis_produk"
            class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jenis_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-red-500"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="mb-4">
        <label for="biaya_produksi" class="block font-bold mb-2">Biaya Produksi:</label>
        <input type="number" id="biaya_produksi" wire:model="biaya_produksi"
            class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['biaya_produksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-red-500"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="mb-4">
        <label for="jumlah_produk" class="block font-bold mb-2">Jumlah Produk:</label>
        <input type="number" id="jumlah_produk" wire:model="jumlah_produk"
            class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jumlah_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-red-500"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="mb-4">
        <label for="persentase_keuntungan" class="block font-bold mb-2">Persentase Keuntungan (%):</label>
        <input type="number" id="persentase_keuntungan" wire:model="persentase_keuntungan"
            class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['persentase_keuntungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-red-500"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="mb-4">
        <button wire:click="hitungTotalHpp" class="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-lg">
            Hitung Total HPP
        </button>
    </div>


    <!--[if BLOCK]><![endif]--><?php if($total_hpp): ?>
        <div>
            <table class="w-full border-collapse">
                <thead>
                    <tr>
                        <th class="border border-gray-500 px-4 py-2">Jenis Produk</th>
                        <th class="border border-gray-500 px-4 py-2">Biaya Produksi</th>
                        <th class="border border-gray-500 px-4 py-2">Jumlah Produk</th>
                        <th class="border border-gray-500 px-4 py-2">Persentase Keuntungan (%)</th>
                        <th class="border border-gray-500 px-4 py-2">Total HPP</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="border border-gray-500 px-4 py-2"><?php echo e($jenis_produk); ?></td>
                        <td class="border border-gray-500 px-4 py-2">Rp
                            <?php echo e(number_format($biaya_produksi, 0, ',', '.')); ?>,00</td>
                        <td class="border border-gray-500 px-4 py-2"><?php echo e($jumlah_produk); ?></td>
                        <td class="border border-gray-500 px-4 py-2"><?php echo e($persentase_keuntungan); ?>%</td>
                        <td class="border border-gray-500 px-4 py-2">Rp <?php echo e(number_format($total_hpp, 0, ',', '.')); ?>,00
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH X:\Laravel\Perikanan\resources\views/livewire/hpp-component.blade.php ENDPATH**/ ?>