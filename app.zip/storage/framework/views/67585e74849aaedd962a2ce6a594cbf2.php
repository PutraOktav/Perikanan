<!-- Page Wrapper -->
<div id="wrapper" class="font-mono text-lg">
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-fish"></i>
            </div>
            <div class="sidebar-brand-text mx-3 hover:font-serif">Aquatic Planning</div>
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">

        <!-- Divider -->
        <hr class="sidebar-divider">

        <!-- Heading -->
        <div class="sidebar-heading">
            <?php echo e(__('Menu')); ?>

        </div>

        <!-- Nav Item -->
        <li class="nav-item hover:font-serif <?php echo e(Nav::isRoute('fish-calculator')); ?>">
            <a class="nav-link" href="<?php echo e(route('fish-calculator')); ?>">
                <i class="fas fa-fw fa-calculator"></i>
                <span><?php echo e(__('Kebutuhan')); ?></span>
            </a>
        </li>

        <li class="nav-item hover:font-serif <?php echo e(Nav::isRoute('fish-farm-sampling-calculator')); ?>">
            <a class="nav-link" href="<?php echo e(route('fish-farm-sampling-calculator')); ?>">
                <i class="fas fa-fw fa-vial"></i>
                <span><?php echo e(__('Kebutuhan Sampling')); ?></span>
            </a>
        </li>

        <li class="nav-item hover:font-serif <?php echo e(Nav::isRoute('hpp')); ?>">
            <a class="nav-link" href="<?php echo e(route('hpp')); ?>">
                <i class="fas fa-money-bill-alt"></i>
                <span><?php echo e(__('HPP')); ?></span>
            </a>
        </li>

        <!-- Heading -->
        <div class="sidebar-heading">
            <?php echo e(__('Transaksi Menu')); ?>

        </div>

        <li class="nav-item hover:font-serif <?php echo e(Nav::isRoute('transaksi')); ?>">
            <a class="nav-link" href="<?php echo e(route('transaksi')); ?>">
                <i class="fas fa-fw fa-exchange-alt"></i>
                <span><?php echo e(__('Transaksi')); ?></span>
            </a>
        </li>

        <!-- Heading -->
        <div class="sidebar-heading">
            <?php echo e(__('Stok')); ?>

        </div>

        <li class="nav-item hover:font-serif <?php echo e(Nav::isRoute('feed-transactions')); ?>">
            <a class="nav-link" href="<?php echo e(route('feed-transactions')); ?>">
                <i class="fas fa-fw fa-seedling"></i>
                <span><?php echo e(__('Pakan')); ?></span>
            </a>
        </li>

        <li class="nav-item hover:font-serif <?php echo e(Nav::isRoute('fish-transactions')); ?>">
            <a class="nav-link" href="<?php echo e(route('fish-transactions')); ?>">
                <i class="fas fa-fw fa-fish"></i>
                <span><?php echo e(__('Ikan')); ?></span>
            </a>
        </li>

        <li class="nav-item hover:font-serif <?php echo e(Nav::isRoute('medicine-transactions')); ?>">
            <a class="nav-link" href="<?php echo e(route('medicine-transactions')); ?>">
                <i class="fas fa-fw fa-pills"></i>
                <span><?php echo e(__('Obat')); ?></span>
            </a>
        </li>

        <li class="nav-item hover:font-serif <?php echo e(Nav::isRoute('other-need-transactions')); ?>">
            <a class="nav-link" href="<?php echo e(route('other-need-transactions')); ?>">
                <i class="fas fa-fw fa-tools"></i>
                <span><?php echo e(__('Alat')); ?></span>
            </a>
        </li>


        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">
        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>
    </ul>
    <!-- End of Sidebar -->
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>
            </nav>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">
                <?php echo $__env->yieldPushContent('notif'); ?>
                <?php echo $__env->yieldContent('main-content'); ?>

            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- End of Main Content -->
        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright Aqua Planning 2021 - <?php echo e(date('Y')); ?></span><br>
                    <a href="https://wa.me/6289506943980" class="text-blue-500 hover:text-blue-700">
                        📞 Putra Winly Octavianto
                    </a>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->
    </div>
    <!-- End of Content Wrapper -->
</div>
<?php /**PATH X:\LARAVEL\Perikanan\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>