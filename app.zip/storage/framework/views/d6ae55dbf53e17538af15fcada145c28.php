    <body class="font-sans antialiased bg-gray-100">
        <div class="container mx-auto p-8">
            <h1 class="text-2xl font-bold mb-4">Daftar Transaksi</h1>
            <table class="w-full bg-white rounded-lg shadow-lg">
                <thead>
                    <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                        <th class="py-3 px-6 text-left">Jenis Ikan</th>
                        <th class="py-3 px-6 text-left">Jumlah</th>
                        <th class="py-3 px-6 text-left">Harga per Unit</th>
                        <th class="py-3 px-6 text-left">Total Harga</th>
                        <th class="py-3 px-6 text-left">Tanggal Transaksi</th>
                    </tr>
                </thead>
                <tbody class="text-gray-600 text-sm font-light">
                    <?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b border-gray-200 hover:bg-gray-100">
                            <td class="py-3 px-6 text-left"><?php echo e($transaksi->jenis_ikan); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo e($transaksi->jumlah); ?> Ekor</td>
                            <td class="py-3 px-6 text-left">Rp. <?php echo e($transaksi->harga_per_unit); ?></td>
                            <td class="py-3 px-6 text-left">Rp. <?php echo e($transaksi->jumlah * $transaksi->harga_per_unit); ?>

                            </td>
                            <td class="py-3 px-6 text-left"><?php echo e($transaksi->tanggal_transaksi); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </body>
<?php /**PATH /home/pzgbtwqf/aquaticplanning.nokt.tech/perikanan/resources/views/pdf/transaksi.blade.php ENDPATH**/ ?>